package com.example.rukeyboard

import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions

class TranslatorIME : InputMethodService() {

    private val buf = StringBuilder()          // English text typed so far
    private val cache = HashMap<String, String>()
    private val ui = Handler(Looper.getMainLooper())
    private var previewJob: Runnable? = null

    private var shift = false
    private var symbols = false
    private var translateOn = true
    private var wordMode = false               // false = sentence (press Translate), true = per word on Space
    private var passwordField = false

    private lateinit var preview: TextView
    private lateinit var rows: LinearLayout
    private lateinit var toggleBtn: TextView
    private lateinit var modeBtn: TextView

    private val translator by lazy {
        Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.RUSSIAN).build()
        )
    }
    private var modelReady = false

    override fun onCreate() {
        super.onCreate()
        translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener { modelReady = true; schedulePreview() }
    }

    override fun onDestroy() { translator.close(); super.onDestroy() }

    override fun onStartInput(info: EditorInfo?, restarting: Boolean) {
        super.onStartInput(info, restarting)
        buf.setLength(0)
        val v = (info?.inputType ?: 0)
        val cls = v and InputType.TYPE_MASK_CLASS
        val variation = v and InputType.TYPE_MASK_VARIATION
        // Never route passwords / emails / URLs / numbers through translation
        passwordField = cls != InputType.TYPE_CLASS_TEXT ||
            variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
            variation == InputType.TYPE_TEXT_VARIATION_URI
        if (::preview.isInitialized) refreshUi()
    }

    override fun onFinishInput() { super.onFinishInput(); buf.setLength(0) }

    // ---------- UI ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFC8CACE.toInt())
            setPadding(dp(2), dp(4), dp(2), dp(4))
        }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        toggleBtn = chip("English → Russian") { translateOn = !translateOn; flushRaw(); refreshUi() }
        modeBtn = chip("Tap Translate") { wordMode = !wordMode; refreshUi() }
        val go = chip("Translate") { translateAndReplace() }.apply {
            setTextColor(0xFFFFFFFF.toInt()); (background as GradientDrawable).setColor(0xFF1E72E8.toInt())
        }
        bar.addView(toggleBtn); bar.addView(modeBtn)
        bar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        bar.addView(go)
        preview = TextView(this).apply {
            textSize = 15f; setTextColor(0xFF111111.toInt()); setPadding(dp(8), dp(4), dp(8), dp(4)); minLines = 2
        }
        rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(bar); root.addView(preview); root.addView(rows)
        refreshUi()
        return root
    }

    private fun chip(label: String, onTap: () -> Unit) = TextView(this).apply {
        text = label; textSize = 14f; setTextColor(0xFF1E72E8.toInt()); typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(12), dp(8), dp(12), dp(8))
        background = GradientDrawable().apply { setColor(0x00000000); cornerRadius = dp(18).toFloat() }
        setOnClickListener { onTap() }
    }

    private fun key(label: String, w: Float = 1f, bg: Int = 0xFFFFFFFF.toInt(), onTap: () -> Unit) = TextView(this).apply {
        text = label; gravity = Gravity.CENTER; textSize = 20f; setTextColor(0xFF111111.toInt())
        background = GradientDrawable().apply { setColor(bg); cornerRadius = dp(6).toFloat() }
        layoutParams = LinearLayout.LayoutParams(0, dp(48), w).apply { setMargins(dp(2), dp(3), dp(2), dp(3)) }
        setOnClickListener { onTap() }
    }

    private fun row(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; v.forEach { addView(it) }
    }

    private fun refreshUi() {
        toggleBtn.text = if (translateOn && !passwordField) "English → Russian" else "Translation OFF"
        modeBtn.text = if (wordMode) "Auto: each word" else "Tap Translate"
        rows.removeAllViews()
        val grey = 0xFFAEB3BA.toInt()
        val r1 = if (symbols) "1234567890" else "qwertyuiop"
        val r2 = if (symbols) "@#$%&-+()" else "asdfghjkl"
        val r3 = if (symbols) "*\"':;!?" else "zxcvbnm"
        fun ch(c: Char) = if (shift && !symbols) c.uppercaseChar().toString() else c.toString()

        rows.addView(row(*r1.map { c -> key(ch(c)) { type(ch(c)) } }.toTypedArray()))
        rows.addView(row(*r2.map { c -> key(ch(c)) { type(ch(c)) } }.toTypedArray()))
        val third = mutableListOf<View>()
        third += key(if (shift) "⇧" else "⇪", 1.5f, grey) { shift = !shift; refreshUi() }
        r3.forEach { c -> third += key(ch(c)) { type(ch(c)) } }
        third += key("⌫", 1.5f, grey) { backspace() }
        rows.addView(row(*third.toTypedArray()))
        rows.addView(row(
            key(if (symbols) "ABC" else "123", 1.5f, grey) { symbols = !symbols; refreshUi() },
            key(",") { type(",") },
            key("Space", 5f) { type(" ") },
            key(".") { type(".") },
            key("↵", 1.5f, 0xFF1E72E8.toInt()) { enter() }
        ))
        updatePreview()
    }

    // ---------- Input logic ----------
    // Letters are typed DIRECTLY into the app's text box (so you see English).
    // We remember what was typed (buf) so Translate can swap exactly that text for Russian.
    private fun raw() = !translateOn || passwordField

    private fun type(s: String) {
        currentInputConnection?.commitText(s, 1)
        if (shift) { shift = false; refreshUi() }
        if (raw()) return
        buf.append(s)
        if (wordMode && s == " ") translateAndReplace() else schedulePreview()
    }

    private fun backspace() {
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        if (!raw() && buf.isNotEmpty()) { buf.setLength(buf.length - 1); schedulePreview() }
    }

    // Enter is always a normal Enter / Send. It never translates.
    private fun enter() {
        buf.setLength(0); updatePreview()
        val ic = currentInputConnection ?: return
        val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE
        if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) ic.performEditorAction(action)
        else sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
    }

    private fun flushRaw() { buf.setLength(0); updatePreview() }

    // If you move the cursor, paste, or the app clears the box after Send, forget the tracked text.
    override fun onUpdateSelection(os: Int, oe: Int, ns: Int, ne: Int, cs: Int, ce: Int) {
        super.onUpdateSelection(os, oe, ns, ne, cs, ce)
        if (buf.isEmpty()) return
        val before = currentInputConnection?.getTextBeforeCursor(buf.length, 0)?.toString()
        if (ns != ne || before != buf.toString()) { buf.setLength(0); schedulePreview() }
    }

    // Replace the English you typed with Russian, in place.
    private fun translateAndReplace() {
        if (passwordField || !translateOn) return
        val ic = currentInputConnection ?: return
        val src = buf.toString()
        if (src.isNotBlank() && ic.getTextBeforeCursor(src.length, 0)?.toString() == src) {
            buf.setLength(0); updatePreview()
            val lead = src.take(src.length - src.trimStart().length)
            val trail = src.takeLast(src.length - src.trimEnd().length)
            translate(src.trim()) { ru ->
                val c = currentInputConnection ?: return@translate
                if (c.getTextBeforeCursor(src.length, 0)?.toString() == src) {
                    c.beginBatchEdit()
                    c.deleteSurroundingText(src.length, 0)
                    c.commitText(lead + ru + trail, 1)
                    c.endBatchEdit()
                }
            }
            return
        }
        // Fallback: text was pasted / cursor moved -> translate the whole box
        val b = ic.getTextBeforeCursor(2000, 0)?.toString() ?: ""
        val a2 = ic.getTextAfterCursor(2000, 0)?.toString() ?: ""
        val all = (b + a2).trim()
        if (all.isEmpty()) return
        buf.setLength(0)
        translate(all) { ru ->
            val c = currentInputConnection ?: return@translate
            c.beginBatchEdit()
            c.deleteSurroundingText(b.length, a2.length)
            c.commitText(ru, 1)
            c.endBatchEdit()
        }
    }

    // ---------- Translation ----------
    private fun translate(src: String, cb: (String) -> Unit) {
        cache[src]?.let { cb(it); return }
        translator.translate(src)
            .addOnSuccessListener { if (cache.size > 500) cache.clear(); cache[src] = it; cb(it) }
            .addOnFailureListener { if (::preview.isInitialized) preview.text = "Russian model not downloaded yet — connect to internet once." }
    }

    private fun schedulePreview() {
        previewJob?.let { ui.removeCallbacks(it) }
        val job = Runnable { updatePreview() }
        previewJob = job
        ui.postDelayed(job, 120)
    }

    private fun updatePreview() {
        if (!::preview.isInitialized) return
        val src = buf.toString().trim()
        if (raw()) { preview.text = if (passwordField) "Secure field: typing directly, no translation" else ""; return }
        if (src.isEmpty()) { preview.text = if (modelReady) "Type English…" else "Downloading Russian model (one time)…"; return }
        translate(src) { ru -> if (src == buf.toString().trim()) preview.text = "$src\n→ $ru" }
    }
}

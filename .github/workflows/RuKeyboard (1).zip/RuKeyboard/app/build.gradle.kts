plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.example.rukeyboard"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.rukeyboard"
        minSdk = 23
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    // On-device neural translation (offline after one-time model download, no limits, no API key)
    implementation("com.google.mlkit:translate:17.0.3")
}
